# 简易领地 SimpleClaims · 使用说明

适用：**Minecraft Java 26.3 + Fabric**。纯服务端，原版客户端也能用。

## 1. 安装

把这两个文件放到服务器 `mods/` 文件夹：

```text
mods/
├─ simpleclaims-1.0.0.jar
└─ fabric-api-0.165.2+26.3.jar
```

需要 Fabric Loader **0.20.1+**、Fabric API **0.165.2+26.3**、Java **25**。

启动服务器，看到日志 `SimpleClaims ready: ...` 即安装成功。

## 2. 30 秒圈第一块地

1. 在游戏里输入 `/claim tool`，拿到一把金铲。
2. 用金铲**右键**一个方块，选角 1。
3. 用金铲**左键**点对角方块，领地立即创建。

完成后会看到聊天提示和一圈粒子。领地保护**整列高度**（从基岩到天空），按世界分开。

## 3. 日常使用

| 想做什么 | 输入 |
| --- | --- |
| 查看帮助 / 快捷按钮 | `/claim` |
| 再领一把金铲 | `/claim tool` |
| 看脚下领地信息 | `/claim info` |
| 看自己的全部领地 | `/claim list` |
| 信任朋友 | 站在自己领地里：`/claim trust 玩家名` |
| 取消信任 | 站在自己领地里：`/claim untrust 玩家名` |
| 删除领地 | 站在自己领地里：`/claim delete`，再确认 |

**信任说明**：`/claim trust` 只对被信任的**当前这块领地**生效；被信任玩家必须在线，才能记录准确 UUID。

**删除说明**：`/claim delete` 会要求二次确认，30 秒内点击聊天栏的 `[确认删除]`，或输入 `/claim delete confirm`。

## 4. 管理员

OP 等级 **2 或更高**自动拥有全部领地权限（放置、破坏、开箱），并可使用：

```text
/claim admin list [玩家]
/claim admin info
/claim admin unclaim
/claim admin delete <玩家>
/claim admin delete <玩家> confirm
/claim admin reload
```

## 5. 默认限制

每人最多 **3** 块领地，每块最小 **3×3**、单边最大 **64** 格。

服务器管理员可以改 `config/simpleclaims.json`，然后执行 `/claim admin reload`：

```json
{
  "maxClaimsPerPlayer": 3,
  "minClaimWidth": 3,
  "maxClaimWidth": 64,
  "showEnterMessages": true,
  "showBorderParticles": true,
  "protectContainers": true,
  "joinHint": true
}
```

- `protectContainers: true` 保护箱子、木桶、熔炉等带界面的容器。
- 关闭后仍然保护方块放置/破坏。
- 已有领地不会因为调小上限而被删除。

## 6. 数据

- 领地数据：`world/simpleclaims-data.json`（实时保存，带 `.bak` 备份）
- 配置：`config/simpleclaims.json`

## 7. 注意事项

- 金铲是圈地工具，拿着它时左/右键不会正常挖方块；需要挖方块请切换其他物品。
- 当前版本保护的是**玩家放置方块、玩家破坏方块、打开带界面的容器**。TNT/苦力怕爆炸、火焰、活塞、实体交互不在 1.0.0 的保护范围内。
- 管理员（OP 2+）绕过领地保护是设计行为。
- 卸载模组后，已保存的领地 JSON 仍在；重新安装即可继续使用。

遇到问题先看服务器日志里的 `simpleclaims` 行，通常能看到配置加载、领地保存和错误原因。
