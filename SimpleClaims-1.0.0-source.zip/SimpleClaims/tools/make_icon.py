from PIL import Image, ImageDraw

S = 4
W = 128 * S
img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# Rounded background with a simple vertical gradient.
for y in range(W):
    t = y / (W - 1)
    r = int(13 + (20 - 13) * t)
    g = int(44 + (76 - 44) * t)
    b = int(39 + (61 - 39) * t)
    d.line([(0, y), (W, y)], fill=(r, g, b, 255))

mask = Image.new("L", (W, W), 0)
md = ImageDraw.Draw(mask)
md.rounded_rectangle([4 * S, 4 * S, W - 4 * S, W - 4 * S], radius=22 * S, fill=255)
img.putalpha(mask)

d = ImageDraw.Draw(img)

# Subtle grid.
for i in range(1, 4):
    p = i * 32 * S
    d.line([(p, 10 * S), (p, W - 10 * S)], fill=(255, 255, 255, 10), width=S)
    d.line([(10 * S, p), (W - 10 * S, p)], fill=(255, 255, 255, 10), width=S)

# Glow behind the shield.
glow = Image.new("RGBA", (W, W), (0, 0, 0, 0))
gd = ImageDraw.Draw(glow)
gd.ellipse([18 * S, 16 * S, 110 * S, 116 * S], fill=(90, 220, 160, 30))
img.alpha_composite(glow)
d = ImageDraw.Draw(img)

# Shield silhouette.
shield = [
    (64 * S, 15 * S),
    (101 * S, 28 * S),
    (98 * S, 65 * S),
    (64 * S, 109 * S),
    (30 * S, 65 * S),
    (27 * S, 28 * S),
]
gold = (232, 184, 74, 255)
gold_light = (255, 221, 128, 255)
gold_dark = (156, 111, 34, 255)
d.polygon(shield, fill=gold_dark)
inner = [
    (64 * S, 21 * S),
    (95 * S, 32 * S),
    (92 * S, 62 * S),
    (64 * S, 101 * S),
    (36 * S, 62 * S),
    (33 * S, 32 * S),
]
d.polygon(inner, fill=(23, 92, 70, 255))

# Inner highlight arc.
d.line([(36 * S, 33 * S), (64 * S, 23 * S), (92 * S, 33 * S)], fill=gold_light, width=2 * S, joint="curve")

# Little house (home = protected base).
house_wall = (246, 238, 208, 255)
house_shadow = (198, 180, 143, 255)
roof = (246, 193, 82, 255)
d.rectangle([45 * S, 58 * S, 83 * S, 86 * S], fill=house_wall)
d.rectangle([45 * S, 58 * S, 83 * S, 61 * S], fill=house_shadow)
d.polygon([(39 * S, 59 * S), (64 * S, 39 * S), (89 * S, 59 * S)], fill=roof)
d.line([(39 * S, 59 * S), (64 * S, 39 * S), (89 * S, 59 * S)], fill=gold_light, width=2 * S, joint="curve")
d.rectangle([58 * S, 67 * S, 70 * S, 86 * S], fill=(130, 85, 43, 255))
d.rectangle([61 * S, 70 * S, 67 * S, 83 * S], fill=(166, 112, 59, 255))
d.ellipse([66 * S, 77 * S, 68 * S, 79 * S], fill=gold_light)

# Small window.
d.rectangle([49 * S, 66 * S, 55 * S, 73 * S], fill=(137, 208, 222, 255))
d.line([(52 * S, 66 * S), (52 * S, 73 * S)], fill=gold_dark, width=S)
d.line([(49 * S, 69 * S), (55 * S, 69 * S)], fill=gold_dark, width=S)

# Corner accents.
for x, y in [(12, 12), (116, 12), (12, 116), (116, 116)]:
    d.ellipse([(x - 2) * S, (y - 2) * S, (x + 2) * S, (y + 2) * S], fill=(111, 219, 166, 255))

img = img.resize((128, 128), Image.Resampling.LANCZOS)
img.save("src/main/resources/assets/simpleclaims/icon.png", "PNG")
