package cn.simpleclaims.claim;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClaimTest {
	private static final String OVERWORLD = "minecraft:overworld";
	private static final String NETHER = "minecraft:the_nether";

	private Claim claim() {
		return new Claim(UUID.randomUUID(), UUID.randomUUID(), "Steve", OVERWORLD,
				10, -5, 20, 7, List.of(), 1L);
	}

	@Test
	void containsIsInclusiveAndDimensionAware() {
		Claim claim = claim();
		assertTrue(claim.contains(OVERWORLD, 10, -5));
		assertTrue(claim.contains(OVERWORLD, 20, 7));
		assertTrue(claim.contains(OVERWORLD, 15, 0));
		assertFalse(claim.contains(OVERWORLD, 9, 0));
		assertFalse(claim.contains(OVERWORLD, 0, 8));
		assertFalse(claim.contains(NETHER, 15, 0));
	}

	@Test
	void widthAndAreaAreInclusive() {
		Claim claim = claim();
		assertEquals(11, claim.widthX());
		assertEquals(13, claim.widthZ());
		assertEquals(143L, claim.area());
	}

	@Test
	void intersectionUsesInclusiveEdges() {
		Claim claim = claim();
		assertTrue(claim.intersects(OVERWORLD, 20, 7, 30, 30));
		assertTrue(claim.intersects(OVERWORLD, 0, 0, 10, 10));
		assertTrue(claim.intersects(OVERWORLD, 12, 0, 13, 1));
		assertFalse(claim.intersects(OVERWORLD, 21, 0, 30, 10));
		assertFalse(claim.intersects(OVERWORLD, 0, 8, 30, 20));
		assertFalse(claim.intersects(NETHER, 0, 0, 30, 30));
	}

	@Test
	void ownerAndTrustedPlayersCanAccessButOthersCannot() {
		UUID owner = UUID.randomUUID();
		UUID friend = UUID.randomUUID();
		UUID stranger = UUID.randomUUID();
		Claim claim = new Claim(UUID.randomUUID(), owner, "Steve", OVERWORLD,
				0, 0, 5, 5, List.of(new TrustedPlayer(friend, "Alex")), 1L);

		assertTrue(claim.canAccess(owner, false));
		assertTrue(claim.canAccess(friend, false));
		assertFalse(claim.canAccess(stranger, false));
		assertTrue(claim.canAccess(stranger, true));
	}

	@Test
	void trustListRejectsOwnerAndDuplicates() {
		UUID owner = UUID.randomUUID();
		UUID friend = UUID.randomUUID();
		Claim claim = new Claim(UUID.randomUUID(), owner, "Steve", OVERWORLD,
				0, 0, 5, 5, List.of(), 1L);

		assertTrue(claim.addTrusted(new TrustedPlayer(friend, "Alex")));
		assertFalse(claim.addTrusted(new TrustedPlayer(friend, "AlexAgain")));
		assertFalse(claim.addTrusted(new TrustedPlayer(owner, "Steve")));
		assertTrue(claim.isTrusted(friend));
		assertTrue(claim.removeTrusted(friend));
		assertFalse(claim.isTrusted(friend));
	}
}
