package cn.simpleclaims.util;

import cn.simpleclaims.claim.Claim;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Server-side particle and sound feedback. No client mod is required.
 */
public final class ClaimVisuals {
	private ClaimVisuals() {
	}

	public static void showCorner(ServerLevel level, BlockPos pos) {
		for (int offset = -3; offset <= 3; offset++) {
			level.sendParticles(ParticleTypes.END_ROD,
					pos.getX() + 0.5, pos.getY() + offset + 0.5, pos.getZ() + 0.5,
					2, 0.12, 0.12, 0.12, 0.0);
		}
	}

	public static void showOutline(ServerLevel level, Claim claim, int y) {
		int step = Math.max(1, Math.max(claim.widthX(), claim.widthZ()) / 24);
		double particleY = y + 0.2;

		for (int x = claim.minX(); x <= claim.maxX(); x += step) {
			particle(level, x + 0.5, particleY, claim.minZ() + 0.5);
			particle(level, x + 0.5, particleY, claim.maxZ() + 0.5);
		}
		for (int z = claim.minZ(); z <= claim.maxZ(); z += step) {
			particle(level, claim.minX() + 0.5, particleY, z + 0.5);
			particle(level, claim.maxX() + 0.5, particleY, z + 0.5);
		}
		// Make sure the last visible corner is always included, even when the step
		// does not divide the side length.
		particle(level, claim.maxX() + 0.5, particleY, claim.maxZ() + 0.5);
	}

	private static void particle(ServerLevel level, double x, double y, double z) {
		level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
	}

	public static void playSelect(ServerLevel level, BlockPos pos) {
		level.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
				SoundEvents.NOTE_BLOCK_PLING, SoundSource.PLAYERS, 0.55f, 1.85f);
	}

	public static void playCreated(ServerPlayer player) {
		player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
				SoundSource.PLAYERS, 0.65f, 1.2f);
	}
}
