package cn.simpleclaims.util;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Prediction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.List;

/**
 * The golden shovel used to select claim corners. Any golden shovel works, so the
 * tool can never be "lost" because of a broken data component.
 */
public final class ClaimTool {
	private ClaimTool() {
	}

	public static boolean isTool(ItemStack stack) {
		return !stack.isEmpty() && stack.getItem() == Items.GOLDEN_SHOVEL;
	}

	public static ItemStack create() {
		ItemStack stack = new ItemStack(Items.GOLDEN_SHOVEL);
		stack.set(DataComponents.CUSTOM_NAME,
				Component.literal("领地工具").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
		stack.set(DataComponents.LORE, new ItemLore(List.of(
				Component.literal("右键方块：选择角 1").withStyle(ChatFormatting.GRAY),
				Component.literal("左键方块：选择角 2 并立即圈地").withStyle(ChatFormatting.GRAY),
				Component.literal("输入 /claim 查看完整帮助").withStyle(ChatFormatting.DARK_GRAY)
		)));
		stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
		return stack;
	}

	public static void give(ServerPlayer player) {
		ItemStack stack = create();
		if (!player.getInventory().add(stack)) {
			player.drop(stack, false, Prediction.SERVER_ONLY);
		}
	}
}
