package cn.simpleclaims.presence;

import cn.simpleclaims.SimpleClaims;
import cn.simpleclaims.claim.Claim;
import cn.simpleclaims.claim.ClaimManager;
import cn.simpleclaims.protection.ProtectionHandler;
import cn.simpleclaims.ui.Messages;
import net.minecraft.ChatFormatting;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Lightweight claim entry/exit messages, plus a one-time join hint.
 */
public final class PresenceNotifier {
	private static final Map<UUID, UUID> LAST_CLAIM = new HashMap<>();
	private static final Set<UUID> WELCOMED = new HashSet<>();

	private PresenceNotifier() {
	}

	public static void tick(MinecraftServer server) {
		if (server.getTickCount() % 20 != 0) {
			return;
		}

		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null) {
			return;
		}

		Set<UUID> online = new HashSet<>();
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			online.add(player.getUUID());
		}

		ProtectionHandler.cleanup(online);
		LAST_CLAIM.keySet().removeIf(id -> !online.contains(id));
		WELCOMED.removeIf(id -> !online.contains(id));

		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (SimpleClaims.CONFIG.joinHint && WELCOMED.add(player.getUUID())) {
				if (manager.countOf(player.getUUID()) == 0) {
					player.sendOverlayMessage(Messages.overlay("输入 /claim 领取金铲，开始圈地", ChatFormatting.GOLD));
				} else {
					player.sendOverlayMessage(Messages.overlay("输入 /claim 查看你的领地", ChatFormatting.AQUA));
				}
			}

			Claim current = manager.findAt(player.level(), player.blockPosition());
			UUID currentId = current == null ? null : current.id();
			UUID previousId = LAST_CLAIM.get(player.getUUID());
			if (java.util.Objects.equals(currentId, previousId)) {
				continue;
			}

			if (SimpleClaims.CONFIG.showEnterMessages) {
				if (current != null) {
					String owner = ownerName(server, current);
					String message;
					if (current.isOwner(player.getUUID())) {
						message = "进入你的领地";
					} else if (current.isTrusted(player.getUUID())) {
						message = "进入 " + owner + " 的领地（已信任）";
					} else if (ProtectionHandler.isAdmin(player)) {
						message = "进入 " + owner + " 的领地（管理员）";
					} else {
						message = "进入 " + owner + " 的领地";
					}
					player.sendOverlayMessage(Messages.overlay(message, ChatFormatting.AQUA));
				} else if (previousId != null) {
					manager.findById(previousId).ifPresent(previous ->
							player.sendOverlayMessage(Messages.overlay("离开 " + ownerName(server, previous) + " 的领地",
									ChatFormatting.DARK_GRAY)));
				}
			}

			if (currentId == null) {
				LAST_CLAIM.remove(player.getUUID());
			} else {
				LAST_CLAIM.put(player.getUUID(), currentId);
			}
		}
	}

	private static String ownerName(MinecraftServer server, Claim claim) {
		ServerPlayer online = server.getPlayerList().getPlayer(claim.ownerId());
		return online != null ? online.getPlainTextName() : claim.ownerName();
	}
}
