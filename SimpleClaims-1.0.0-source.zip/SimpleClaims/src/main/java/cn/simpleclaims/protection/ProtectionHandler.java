package cn.simpleclaims.protection;

import cn.simpleclaims.SimpleClaims;
import cn.simpleclaims.claim.Claim;
import cn.simpleclaims.claim.ClaimManager;
import cn.simpleclaims.claim.CreateResult;
import cn.simpleclaims.command.ClaimCommands;
import cn.simpleclaims.config.ClaimConfig;
import cn.simpleclaims.ui.Messages;
import cn.simpleclaims.util.ClaimTool;
import cn.simpleclaims.util.ClaimVisuals;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.BlockEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * All player-facing protection hooks. The logic is server-authoritative; clients
 * without the mod are rejected by the server exactly like clients with it.
 */
public final class ProtectionHandler {
	private static final long DENY_MESSAGE_COOLDOWN_MS = 1200L;
	private static final Map<UUID, Selection> SELECTIONS = new HashMap<>();
	private static final Map<UUID, Long> LAST_DENIED = new HashMap<>();

	private ProtectionHandler() {
	}

	public static void register() {
		BlockEvents.USE_ITEM_ON.register(ProtectionHandler::onUseItemOn);
		BlockEvents.USE_WITHOUT_ITEM.register(ProtectionHandler::onUseWithoutItem);
		AttackBlockCallback.EVENT.register(ProtectionHandler::onAttackBlock);
		PlayerBlockBreakEvents.BEFORE.register(ProtectionHandler::onBlockBreak);
	}

	/**
	 * Called from the ServerPlayerGameMode mixin before vanilla does anything.
	 * Unlike the block-side event, this also covers sneak-use, because vanilla
	 * skips BlockState.useItemOn when the player is sneaking with an item.
	 */
	public static InteractionResult onUseItemOnIntercepted(ServerPlayer player, Level level, ItemStack stack,
			InteractionHand hand, BlockHitResult hit) {
		BlockPos pos = hit.getBlockPos();
		BlockState state = level.getBlockState(pos);
		return onUseItemOn(stack, state, level, pos, player, hand, hit);
	}

	private static InteractionResult onUseItemOn(ItemStack stack, BlockState state, Level level,
			BlockPos pos, net.minecraft.world.entity.player.Player player, InteractionHand hand,
			BlockHitResult hit) {
		if (hand == InteractionHand.MAIN_HAND && ClaimTool.isTool(stack)) {
			if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer serverPlayer)) {
				// Suppress client-side chest/GUI prediction while holding the claim tool.
				return InteractionResult.SUCCESS;
			}
			if (serverPlayer.isSpectator()) {
				return null;
			}
			selectFirstCorner(serverPlayer, pos);
			return InteractionResult.SUCCESS_SERVER;
		}

		if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer serverPlayer)) {
			return null;
		}
		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null) {
			return null;
		}

		if (SimpleClaims.CONFIG.protectContainers && isContainer(level, pos, state)) {
			Claim denied = firstDenied(serverPlayer, claimsForContainer(manager, level, pos, state));
			if (denied != null) {
				deny(serverPlayer, denied, "打开容器");
				return InteractionResult.FAIL;
			}
		}

		if (isPlacementItem(stack)) {
			BlockPos placementPos = pos.relative(hit.getDirection());
			Claim denied = firstDenied(serverPlayer, claimsAt(manager, level, pos, placementPos));
			if (denied != null) {
				deny(serverPlayer, denied, "放置方块");
				return InteractionResult.FAIL;
			}
		}

		return null;
	}

	private static InteractionResult onUseWithoutItem(BlockState state, Level level, BlockPos pos,
			net.minecraft.world.entity.player.Player player, BlockHitResult hit) {
		if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer serverPlayer)) {
			return null;
		}
		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null || !SimpleClaims.CONFIG.protectContainers) {
			return null;
		}
		if (!isContainer(level, pos, state)) {
			return null;
		}

		Claim denied = firstDenied(serverPlayer, claimsForContainer(manager, level, pos, state));
		if (denied != null) {
			deny(serverPlayer, denied, "打开容器");
			return InteractionResult.FAIL;
		}
		return null;
	}

	/**
	 * Fires before the server starts the destroy-block action, so the client gets
	 * an immediate rejection instead of mining a ghost block for a while.
	 */
	private static InteractionResult onAttackBlock(net.minecraft.world.entity.player.Player player, Level level,
			InteractionHand hand, BlockPos pos, Direction direction) {
		if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer serverPlayer)) {
			return InteractionResult.PASS;
		}
		if (serverPlayer.isSpectator()) {
			return InteractionResult.PASS;
		}

		// The golden shovel is the claim tool: left-clicking sets the second corner.
		if (hand == InteractionHand.MAIN_HAND && ClaimTool.isTool(serverPlayer.getMainHandItem())) {
			selectSecondCorner(serverPlayer, pos);
			return InteractionResult.SUCCESS;
		}

		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null) {
			return InteractionResult.PASS;
		}

		BlockState state = level.getBlockState(pos);
		Claim denied = firstDenied(serverPlayer, claimsForBlockBreak(manager, level, pos, state));
		if (denied != null) {
			deny(serverPlayer, denied, "破坏方块");
			return InteractionResult.FAIL;
		}
		return InteractionResult.PASS;
	}

	private static boolean onBlockBreak(Level level, net.minecraft.world.entity.player.Player player,
			BlockPos pos, BlockState state, net.minecraft.world.level.block.entity.BlockEntity blockEntity) {
		if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer serverPlayer)) {
			return true;
		}

		// Selection normally happens in onAttackBlock; this is a fallback that
		// still prevents a claim tool from actually breaking anything.
		if (ClaimTool.isTool(serverPlayer.getMainHandItem())) {
			return false;
		}

		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null) {
			return true;
		}

		Claim denied = firstDenied(serverPlayer, claimsForBlockBreak(manager, level, pos, state));
		if (denied != null) {
			deny(serverPlayer, denied, "破坏方块");
			return false;
		}
		return true;
	}

	private static boolean isContainer(Level level, BlockPos pos, BlockState state) {
		return state.getMenuProvider(level, pos) != null;
	}

	private static List<Claim> claimsForContainer(ClaimManager manager, Level level, BlockPos pos, BlockState state) {
		List<Claim> claims = new ArrayList<>(2);
		addClaim(claims, manager.findAt(level.dimension().identifier().toString(), pos.getX(), pos.getZ()));

		if (state.getBlock() instanceof ChestBlock && state.getValue(ChestBlock.TYPE) != ChestType.SINGLE) {
			Direction connected = ChestBlock.getConnectedDirection(state);
			BlockPos other = pos.relative(connected);
			addClaim(claims, manager.findAt(level.dimension().identifier().toString(), other.getX(), other.getZ()));
		}
		return claims;
	}

	private static List<Claim> claimsForBlockBreak(ClaimManager manager, Level level, BlockPos pos, BlockState state) {
		// Breaking one half of a double chest must also require access to the other
		// half when that half is inside somebody else's claim.
		return claimsForContainer(manager, level, pos, state);
	}

	private static List<Claim> claimsAt(ClaimManager manager, Level level, BlockPos... positions) {
		List<Claim> claims = new ArrayList<>(2);
		String dimension = level.dimension().identifier().toString();
		for (BlockPos pos : positions) {
			addClaim(claims, manager.findAt(dimension, pos.getX(), pos.getZ()));
		}
		return claims;
	}

	private static void addClaim(List<Claim> claims, Claim claim) {
		if (claim != null && !claims.contains(claim)) {
			claims.add(claim);
		}
	}

	private static Claim firstDenied(ServerPlayer player, List<Claim> claims) {
		if (claims.isEmpty()) {
			return null;
		}
		boolean admin = isAdmin(player);
		for (Claim claim : claims) {
			if (!claim.canAccess(player.getUUID(), admin)) {
				return claim;
			}
		}
		return null;
	}

	public static boolean isAdmin(ServerPlayer player) {
		return Commands.LEVEL_GAMEMASTERS.check(player.permissions());
	}

	private static boolean isPlacementItem(ItemStack stack) {
		Item item = stack.getItem();
		return item instanceof BlockItem || item instanceof BucketItem;
	}

	private static void deny(ServerPlayer player, Claim claim, String action) {
		long now = System.currentTimeMillis();
		long last = LAST_DENIED.getOrDefault(player.getUUID(), 0L);
		if (now - last < DENY_MESSAGE_COOLDOWN_MS) {
			return;
		}
		LAST_DENIED.put(player.getUUID(), now);

		String owner = displayOwner(player, claim);
		player.sendOverlayMessage(Messages.overlay("这是 " + owner + " 的领地，你无权" + action + "。", ChatFormatting.RED));
	}

	public static String displayOwner(ServerPlayer viewer, Claim claim) {
		ServerPlayer online = viewer.level().getServer().getPlayerList().getPlayer(claim.ownerId());
		return online != null ? online.getPlainTextName() : claim.ownerName();
	}

	private static void selectFirstCorner(ServerPlayer player, BlockPos pos) {
		String dimension = player.level().dimension().identifier().toString();
		SELECTIONS.put(player.getUUID(), new Selection(dimension, pos));
		player.sendOverlayMessage(Messages.overlay(
				"角 1: (" + pos.getX() + ", " + pos.getZ() + ")。现在左键点击对角方块。",
				ChatFormatting.GOLD));
		if (SimpleClaims.CONFIG.showBorderParticles) {
			ClaimVisuals.showCorner(player.level(), pos);
		}
		ClaimVisuals.playSelect(player.level(), pos);
	}

	private static void selectSecondCorner(ServerPlayer player, BlockPos pos) {
		Selection selection = SELECTIONS.get(player.getUUID());
		if (selection == null) {
			player.sendOverlayMessage(Messages.overlay("请先用金铲右键点击第一个角。", ChatFormatting.RED));
			return;
		}

		String dimension = player.level().dimension().identifier().toString();
		if (!selection.dimension().equals(dimension)) {
			SELECTIONS.remove(player.getUUID());
			player.sendOverlayMessage(Messages.overlay("换世界了，请重新右键选择角 1。", ChatFormatting.RED));
			return;
		}

		selection.setSecond(pos);
		tryCreate(player);
	}

	public static boolean createFromSelection(ServerPlayer player) {
		Selection selection = SELECTIONS.get(player.getUUID());
		if (selection == null || selection.second() == null) {
			player.sendSystemMessage(Messages.error("还没有两个角。请先用金铲右键选择角 1，再左键选择角 2。"));
			return false;
		}
		return tryCreate(player);
	}

	private static boolean tryCreate(ServerPlayer player) {
		Selection selection = SELECTIONS.get(player.getUUID());
		if (selection == null || selection.second() == null) {
			player.sendSystemMessage(Messages.error("还没有两个角。请先用金铲右键选择角 1，再左键选择角 2。"));
			return false;
		}

		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null) {
			player.sendSystemMessage(Messages.error("领地系统尚未加载，请稍后再试。"));
			return false;
		}

		String currentDimension = player.level().dimension().identifier().toString();
		if (!selection.dimension().equals(currentDimension)) {
			player.sendSystemMessage(Messages.error("你已不在选择领地时的世界，请重新选择两个角。"));
			return false;
		}

		ClaimConfig config = SimpleClaims.CONFIG;
		CreateResult result = manager.create(player, selection.first(), selection.second(), config);
		if (result.success()) {
			Claim claim = result.claim();
			SELECTIONS.remove(player.getUUID());

			player.sendSystemMessage(Messages.success("领地创建成功！范围 " + claim.widthX() + "×" + claim.widthZ()
					+ "，角点 (" + claim.minX() + ", " + claim.minZ() + ") 到 ("
					+ claim.maxX() + ", " + claim.maxZ() + ")。"));
			player.sendSystemMessage(Messages.info("邀请朋友：站在领地里输入 /claim trust 玩家名"));
			player.sendOverlayMessage(Messages.overlay("领地创建成功", ChatFormatting.GREEN));
			if (config.showBorderParticles) {
				ClaimVisuals.showOutline(player.level(), claim, player.blockPosition().getY());
			}
			ClaimVisuals.playCreated(player);
			SimpleClaims.LOGGER.info("{} created claim {} in {} ({},{}..{},{})", player.getPlainTextName(),
					claim.id(), claim.dimension(), claim.minX(), claim.minZ(), claim.maxX(), claim.maxZ());
			return true;
		}

		switch (result.failure()) {
			case TOO_SMALL -> {
				player.sendOverlayMessage(Messages.overlay("领地太小", ChatFormatting.RED));
				player.sendSystemMessage(Messages.error("领地太小：每条边至少 " + config.minClaimWidth
						+ " 格（当前 " + selection.widthX() + "×" + selection.widthZ() + "）。"));
			}
			case TOO_LARGE -> {
				player.sendOverlayMessage(Messages.overlay("领地太大", ChatFormatting.RED));
				player.sendSystemMessage(Messages.error("领地太大：每条边最多 " + config.maxClaimWidth
						+ " 格（当前 " + selection.widthX() + "×" + selection.widthZ() + "）。"));
			}
			case LIMIT -> {
				player.sendOverlayMessage(Messages.overlay("领地数量已达上限", ChatFormatting.RED));
				player.sendSystemMessage(Messages.error("你最多拥有 " + config.maxClaimsPerPlayer
						+ " 块领地。删除一块：站在领地里输入 /claim delete"));
			}
			case OVERLAP -> {
				Claim conflict = result.conflict();
				String owner = conflict == null ? "其他玩家" : displayOwner(player, conflict);
				player.sendOverlayMessage(Messages.overlay("和 " + owner + " 的领地重叠", ChatFormatting.RED));
				player.sendSystemMessage(Messages.error("这里和 " + owner + " 的领地重叠，无法创建。"));
			}
			case SAVE_FAILED -> {
				player.sendOverlayMessage(Messages.overlay("保存失败", ChatFormatting.RED));
				player.sendSystemMessage(Messages.error("领地保存失败，请联系管理员查看服务器日志。"));
			}
			default -> player.sendSystemMessage(Messages.error("领地创建失败。"));
		}
		return false;
	}

	public static Selection getSelection(UUID playerId) {
		return SELECTIONS.get(playerId);
	}

	public static void clearSelection(UUID playerId) {
		SELECTIONS.remove(playerId);
	}

	public static void cleanup(Set<UUID> online) {
		SELECTIONS.keySet().removeIf(id -> !online.contains(id));
		LAST_DENIED.keySet().removeIf(id -> !online.contains(id));
		ClaimCommands.cleanup(online);
	}

	public static final class Selection {
		private final String dimension;
		private final BlockPos first;
		private BlockPos second;

		private Selection(String dimension, BlockPos first) {
			this.dimension = dimension;
			this.first = first;
		}

		public String dimension() {
			return dimension;
		}

		public BlockPos first() {
			return first;
		}

		public BlockPos second() {
			return second;
		}

		private void setSecond(BlockPos second) {
			this.second = second;
		}

		public int widthX() {
			return second == null ? 0 : Math.abs(first.getX() - second.getX()) + 1;
		}

		public int widthZ() {
			return second == null ? 0 : Math.abs(first.getZ() - second.getZ()) + 1;
		}
	}
}
