package cn.simpleclaims;

import cn.simpleclaims.claim.ClaimManager;
import cn.simpleclaims.command.ClaimCommands;
import cn.simpleclaims.config.ClaimConfig;
import cn.simpleclaims.presence.PresenceNotifier;
import cn.simpleclaims.protection.ProtectionHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

/**
 * SimpleClaims - low-friction private claims for Fabric servers.
 *
 * <p>The mod is fully server-side. Vanilla clients can join and use all of its
 * commands, protection and feedback.</p>
 */
public class SimpleClaims implements ModInitializer {
	public static final String MOD_ID = "simpleclaims";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static ClaimConfig CONFIG;
	public static ClaimManager CLAIMS;

	private static Path configPath;

	@Override
	public void onInitialize() {
		configPath = FabricLoader.getInstance().getConfigDir().resolve("simpleclaims.json");
		CONFIG = ClaimConfig.load(configPath);

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				ClaimCommands.register(dispatcher));
		ProtectionHandler.register();

		ServerLifecycleEvents.SERVER_STARTED.register(server -> {
			CLAIMS = ClaimManager.load(server);
			LOGGER.info("SimpleClaims ready: {} claim(s), max {} per player, width {}-{}",
					CLAIMS.size(), CONFIG.maxClaimsPerPlayer, CONFIG.minClaimWidth, CONFIG.maxClaimWidth);
		});

		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			if (CLAIMS != null) {
				CLAIMS.save();
				CLAIMS = null;
			}
		});

		ServerTickEvents.END_SERVER_TICK.register(PresenceNotifier::tick);
	}

	public static void reloadConfig() {
		if (configPath == null) {
			configPath = FabricLoader.getInstance().getConfigDir().resolve("simpleclaims.json");
		}
		CONFIG = ClaimConfig.load(configPath);
		LOGGER.info("Reloaded config: maxClaims={}, width={}-{}, protectContainers={}",
				CONFIG.maxClaimsPerPlayer, CONFIG.minClaimWidth, CONFIG.maxClaimWidth, CONFIG.protectContainers);
	}
}
