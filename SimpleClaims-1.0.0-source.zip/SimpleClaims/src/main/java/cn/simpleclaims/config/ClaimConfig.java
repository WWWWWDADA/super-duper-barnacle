package cn.simpleclaims.config;

import cn.simpleclaims.SimpleClaims;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Server-side settings, stored in config/simpleclaims.json.
 */
public final class ClaimConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

	/** Maximum number of claims one player may own. */
	public int maxClaimsPerPlayer = 3;
	/** Smallest allowed side length of a claim, in blocks. */
	public int minClaimWidth = 3;
	/** Largest allowed side length of a claim, in blocks. */
	public int maxClaimWidth = 64;
	/** Show "entered/left claim" action bar messages. */
	public boolean showEnterMessages = true;
	/** Draw a short particle outline after selecting/creating a claim. */
	public boolean showBorderParticles = true;
	/** Protect containers (chests, barrels, furnaces, ...) inside claims. */
	public boolean protectContainers = true;
	/** Show a one-line hint when a player joins. */
	public boolean joinHint = true;

	public static ClaimConfig load(Path file) {
		ClaimConfig config = new ClaimConfig();
		if (Files.exists(file)) {
			try {
				String json = Files.readString(file, StandardCharsets.UTF_8);
				ClaimConfig loaded = GSON.fromJson(json, ClaimConfig.class);
				if (loaded != null) {
					config = loaded;
				}
			} catch (IOException | RuntimeException exception) {
				SimpleClaims.LOGGER.error("Could not read config {}. Using defaults.", file, exception);
				config = new ClaimConfig();
			}
		} else {
			config.save(file);
		}

		config.normalize();
		return config;
	}

	public void normalize() {
		int originalMaxClaims = maxClaimsPerPlayer;
		int originalMinWidth = minClaimWidth;
		int originalMaxWidth = maxClaimWidth;

		maxClaimsPerPlayer = Math.max(1, Math.min(100, maxClaimsPerPlayer));
		minClaimWidth = Math.max(1, Math.min(512, minClaimWidth));
		maxClaimWidth = Math.max(minClaimWidth, Math.min(512, maxClaimWidth));

		if (maxClaimsPerPlayer != originalMaxClaims
				|| minClaimWidth != originalMinWidth
				|| maxClaimWidth != originalMaxWidth) {
			SimpleClaims.LOGGER.warn("Adjusted invalid claim limits to claims={}, minWidth={}, maxWidth={}",
					maxClaimsPerPlayer, minClaimWidth, maxClaimWidth);
		}
	}

	public void save(Path file) {
		try {
			Path parent = file.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}
			Files.writeString(file, GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException exception) {
			SimpleClaims.LOGGER.error("Could not write config {}", file, exception);
		}
	}
}
