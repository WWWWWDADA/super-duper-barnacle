package cn.simpleclaims.claim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * A two-dimensional, full-height claim. Bounds are inclusive and horizontal only.
 */
public final class Claim {
	private final UUID id;
	private final UUID ownerId;
	private final String ownerName;
	private final String dimension;
	private final int minX;
	private final int minZ;
	private final int maxX;
	private final int maxZ;
	private final long createdAt;
	private final List<TrustedPlayer> trusted;

	public Claim(UUID id, UUID ownerId, String ownerName, String dimension,
			int minX, int minZ, int maxX, int maxZ,
			List<TrustedPlayer> trusted, long createdAt) {
		this.id = Objects.requireNonNull(id, "id");
		this.ownerId = Objects.requireNonNull(ownerId, "ownerId");
		this.ownerName = ownerName == null || ownerName.isBlank() ? "未知玩家" : ownerName;
		this.dimension = Objects.requireNonNull(dimension, "dimension");
		this.minX = Math.min(minX, maxX);
		this.minZ = Math.min(minZ, maxZ);
		this.maxX = Math.max(minX, maxX);
		this.maxZ = Math.max(minZ, maxZ);
		this.createdAt = createdAt;
		this.trusted = trusted == null ? new ArrayList<>() : new ArrayList<>(trusted);
	}

	public UUID id() {
		return id;
	}

	public UUID ownerId() {
		return ownerId;
	}

	public String ownerName() {
		return ownerName;
	}

	public String dimension() {
		return dimension;
	}

	public int minX() {
		return minX;
	}

	public int minZ() {
		return minZ;
	}

	public int maxX() {
		return maxX;
	}

	public int maxZ() {
		return maxZ;
	}

	public int widthX() {
		return maxX - minX + 1;
	}

	public int widthZ() {
		return maxZ - minZ + 1;
	}

	public long area() {
		return (long) widthX() * (long) widthZ();
	}

	public long createdAt() {
		return createdAt;
	}

	public boolean isOwner(UUID playerId) {
		return ownerId.equals(playerId);
	}

	public boolean isTrusted(UUID playerId) {
		for (TrustedPlayer player : trusted) {
			if (player.id().equals(playerId)) {
				return true;
			}
		}
		return false;
	}

	public boolean canAccess(UUID playerId, boolean admin) {
		return admin || isOwner(playerId) || isTrusted(playerId);
	}

	public boolean contains(String dimension, int x, int z) {
		return this.dimension.equals(dimension) && x >= minX && x <= maxX && z >= minZ && z <= maxZ;
	}

	public boolean intersects(String dimension, int otherMinX, int otherMinZ, int otherMaxX, int otherMaxZ) {
		if (!this.dimension.equals(dimension)) {
			return false;
		}
		return minX <= otherMaxX && maxX >= otherMinX && minZ <= otherMaxZ && maxZ >= otherMinZ;
	}

	public List<TrustedPlayer> trusted() {
		return Collections.unmodifiableList(trusted);
	}

	public boolean addTrusted(TrustedPlayer player) {
		if (player == null || player.id().equals(ownerId) || isTrusted(player.id())) {
			return false;
		}
		trusted.add(player);
		return true;
	}

	public boolean removeTrusted(UUID playerId) {
		return trusted.removeIf(player -> player.id().equals(playerId));
	}

	public Optional<TrustedPlayer> findTrusted(UUID playerId) {
		return trusted.stream().filter(player -> player.id().equals(playerId)).findFirst();
	}

	public Optional<TrustedPlayer> findTrustedByName(String name) {
		for (TrustedPlayer player : trusted) {
			if (player.name().equalsIgnoreCase(name)) {
				return Optional.of(player);
			}
		}
		return Optional.empty();
	}

	@Override
	public boolean equals(Object other) {
		return other instanceof Claim claim && id.equals(claim.id);
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public String toString() {
		return "Claim[" + id + " owner=" + ownerName + " " + dimension + " "
				+ minX + "," + minZ + ".." + maxX + "," + maxZ + "]";
	}
}
