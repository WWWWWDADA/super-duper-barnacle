package cn.simpleclaims.claim;

/**
 * Result of attempting to create a claim.
 */
public record CreateResult(Claim claim, Failure failure, Claim conflict) {
	public enum Failure {
		NONE,
		TOO_SMALL,
		TOO_LARGE,
		LIMIT,
		OVERLAP,
		SAVE_FAILED
	}

	public boolean success() {
		return failure == Failure.NONE;
	}
}
