package cn.simpleclaims.claim;

import cn.simpleclaims.SimpleClaims;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Human-readable JSON persistence. Saves are atomic and keep a .bak of the previous file.
 */
public final class ClaimStorage {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final int FORMAT_VERSION = 1;

	private ClaimStorage() {
	}

	public static List<Claim> load(Path file) {
		List<Claim> claims = new ArrayList<>();
		if (!Files.exists(file)) {
			return claims;
		}

		try {
			String json = Files.readString(file, StandardCharsets.UTF_8);
			DataRoot root = GSON.fromJson(json, DataRoot.class);
			if (root == null || root.claims == null) {
				return claims;
			}

			Set<UUID> seenIds = new HashSet<>();
			for (DataClaim data : root.claims) {
				if (data == null) {
					continue;
				}
				try {
					UUID id = UUID.fromString(data.id);
					UUID owner = UUID.fromString(data.owner);
					if (!seenIds.add(id) || data.dimension == null || data.dimension.isBlank()
							|| data.minX > data.maxX || data.minZ > data.maxZ) {
						SimpleClaims.LOGGER.warn("Skipping invalid claim entry: {}", data.id);
						continue;
					}

					List<TrustedPlayer> trusted = new ArrayList<>();
					if (data.trusted != null) {
						for (DataTrusted entry : data.trusted) {
							if (entry == null) {
								continue;
							}
							try {
								UUID trustedId = UUID.fromString(entry.id);
								if (!trustedId.equals(owner)) {
									trusted.add(new TrustedPlayer(trustedId, entry.name));
								}
							} catch (RuntimeException exception) {
								SimpleClaims.LOGGER.warn("Skipping invalid trusted player {} in claim {}", entry.id, data.id);
							}
						}
					}

					claims.add(new Claim(id, owner, data.ownerName, data.dimension,
							data.minX, data.minZ, data.maxX, data.maxZ,
							trusted, data.createdAt));
				} catch (RuntimeException exception) {
					SimpleClaims.LOGGER.warn("Skipping invalid claim entry {}", data.id, exception);
				}
			}
			SimpleClaims.LOGGER.info("Loaded {} claim(s) from {}", claims.size(), file);
		} catch (IOException | RuntimeException exception) {
			SimpleClaims.LOGGER.error("Could not read claim data from {}", file, exception);
			backupCorrupt(file);
		}

		return claims;
	}

	public static boolean save(Path file, Collection<Claim> claims) {
		DataRoot root = new DataRoot();
		root.version = FORMAT_VERSION;
		for (Claim claim : claims) {
			DataClaim data = new DataClaim();
			data.id = claim.id().toString();
			data.owner = claim.ownerId().toString();
			data.ownerName = claim.ownerName();
			data.dimension = claim.dimension();
			data.minX = claim.minX();
			data.minZ = claim.minZ();
			data.maxX = claim.maxX();
			data.maxZ = claim.maxZ();
			data.createdAt = claim.createdAt();
			for (TrustedPlayer player : claim.trusted()) {
				DataTrusted trusted = new DataTrusted();
				trusted.id = player.id().toString();
				trusted.name = player.name();
				data.trusted.add(trusted);
			}
			root.claims.add(data);
		}

		Path parent = file.getParent();
		Path temp = file.resolveSibling(file.getFileName() + ".tmp");
		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}
			Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
			if (Files.exists(file)) {
				try {
					Files.copy(file, file.resolveSibling(file.getFileName() + ".bak"),
							StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException exception) {
					SimpleClaims.LOGGER.warn("Could not create claim backup {}", file, exception);
				}
			}
			try {
				Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			SimpleClaims.LOGGER.error("Could not save claim data to {}", file, exception);
			try {
				Files.deleteIfExists(temp);
			} catch (IOException ignored) {
			}
			return false;
		}
	}

	private static void backupCorrupt(Path file) {
		try {
			if (!Files.exists(file)) {
				return;
			}
			Path backup = file.resolveSibling(file.getFileName() + ".corrupt-" + System.currentTimeMillis());
			Files.copy(file, backup, StandardCopyOption.REPLACE_EXISTING);
			SimpleClaims.LOGGER.warn("The unreadable claim file was backed up to {}", backup);
		} catch (IOException exception) {
			SimpleClaims.LOGGER.warn("Could not back up unreadable claim data", exception);
		}
	}

	private static final class DataRoot {
		int version = FORMAT_VERSION;
		List<DataClaim> claims = new ArrayList<>();
	}

	private static final class DataClaim {
		String id;
		String owner;
		String ownerName;
		String dimension;
		int minX;
		int minZ;
		int maxX;
		int maxZ;
		long createdAt;
		List<DataTrusted> trusted = new ArrayList<>();
	}

	private static final class DataTrusted {
		String id;
		String name;
	}
}
