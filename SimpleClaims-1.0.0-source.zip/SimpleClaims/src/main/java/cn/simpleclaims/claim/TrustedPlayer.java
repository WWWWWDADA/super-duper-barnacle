package cn.simpleclaims.claim;

import java.util.UUID;

/**
 * A player that the claim owner has explicitly allowed.
 */
public record TrustedPlayer(UUID id, String name) {
	public TrustedPlayer {
		if (id == null) {
			throw new IllegalArgumentException("id");
		}
		if (name == null || name.isBlank()) {
			name = "未知玩家";
		}
	}
}
