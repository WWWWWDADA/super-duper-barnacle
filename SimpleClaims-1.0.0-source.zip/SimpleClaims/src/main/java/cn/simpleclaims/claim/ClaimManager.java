package cn.simpleclaims.claim;

import cn.simpleclaims.config.ClaimConfig;
import cn.simpleclaims.claim.CreateResult.Failure;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Owns every claim on the server. Mutations write to disk immediately.
 */
public final class ClaimManager {
	private final List<Claim> claims;
	private final Path dataFile;

	private ClaimManager(List<Claim> claims, Path dataFile) {
		this.claims = new ArrayList<>(claims);
		this.dataFile = dataFile;
	}

	public static ClaimManager load(MinecraftServer server) {
		Path file = server.getWorldPath(LevelResource.ROOT).resolve("simpleclaims-data.json");
		return new ClaimManager(ClaimStorage.load(file), file);
	}

	public List<Claim> allClaims() {
		return Collections.unmodifiableList(claims);
	}

	public int size() {
		return claims.size();
	}

	public Optional<Claim> findById(UUID id) {
		for (Claim claim : claims) {
			if (claim.id().equals(id)) {
				return Optional.of(claim);
			}
		}
		return Optional.empty();
	}

	public Claim findAt(ServerLevel level, BlockPos pos) {
		return findAt(level.dimension().identifier().toString(), pos.getX(), pos.getZ());
	}

	public Claim findAt(String dimension, int x, int z) {
		for (Claim claim : claims) {
			if (claim.contains(dimension, x, z)) {
				return claim;
			}
		}
		return null;
	}

	public List<Claim> claimsOf(UUID ownerId) {
		List<Claim> result = new ArrayList<>();
		for (Claim claim : claims) {
			if (claim.ownerId().equals(ownerId)) {
				result.add(claim);
			}
		}
		result.sort(Comparator.comparingLong(Claim::createdAt));
		return result;
	}

	public int countOf(UUID ownerId) {
		int count = 0;
		for (Claim claim : claims) {
			if (claim.ownerId().equals(ownerId)) {
				count++;
			}
		}
		return count;
	}

	public List<Claim> claimsByName(String name) {
		List<Claim> result = new ArrayList<>();
		for (Claim claim : claims) {
			if (claim.ownerName().equalsIgnoreCase(name)) {
				result.add(claim);
			}
		}
		return result;
	}

	public CreateResult create(ServerPlayer player, BlockPos first, BlockPos second, ClaimConfig config) {
		int minX = Math.min(first.getX(), second.getX());
		int minZ = Math.min(first.getZ(), second.getZ());
		int maxX = Math.max(first.getX(), second.getX());
		int maxZ = Math.max(first.getZ(), second.getZ());
		int widthX = maxX - minX + 1;
		int widthZ = maxZ - minZ + 1;

		if (widthX < config.minClaimWidth || widthZ < config.minClaimWidth) {
			return new CreateResult(null, Failure.TOO_SMALL, null);
		}
		if (widthX > config.maxClaimWidth || widthZ > config.maxClaimWidth) {
			return new CreateResult(null, Failure.TOO_LARGE, null);
		}
		if (countOf(player.getUUID()) >= config.maxClaimsPerPlayer) {
			return new CreateResult(null, Failure.LIMIT, null);
		}

		String dimension = player.level().dimension().identifier().toString();
		for (Claim claim : claims) {
			if (claim.intersects(dimension, minX, minZ, maxX, maxZ)) {
				return new CreateResult(null, Failure.OVERLAP, claim);
			}
		}

		Claim claim = new Claim(UUID.randomUUID(), player.getUUID(), player.getPlainTextName(),
				dimension, minX, minZ, maxX, maxZ, new ArrayList<>(), System.currentTimeMillis());
		claims.add(claim);
		if (!save()) {
			claims.remove(claim);
			return new CreateResult(null, Failure.SAVE_FAILED, null);
		}
		return new CreateResult(claim, Failure.NONE, null);
	}

	public boolean addTrusted(Claim claim, UUID playerId, String playerName) {
		if (!claim.addTrusted(new TrustedPlayer(playerId, playerName))) {
			return false;
		}
		if (!save()) {
			claim.removeTrusted(playerId);
			return false;
		}
		return true;
	}

	public boolean removeTrusted(Claim claim, UUID playerId) {
		Optional<TrustedPlayer> removed = claim.findTrusted(playerId);
		if (removed.isEmpty()) {
			return false;
		}
		claim.removeTrusted(playerId);
		if (!save()) {
			claim.addTrusted(removed.get());
			return false;
		}
		return true;
	}

	public boolean delete(Claim claim) {
		int index = claims.indexOf(claim);
		if (index < 0) {
			return false;
		}
		claims.remove(index);
		if (!save()) {
			claims.add(index, claim);
			return false;
		}
		return true;
	}

	public int deleteAll(Collection<Claim> toDelete) {
		List<Claim> removed = new ArrayList<>();
		for (Claim claim : toDelete) {
			if (claims.remove(claim)) {
				removed.add(claim);
			}
		}
		if (removed.isEmpty()) {
			return 0;
		}
		if (!save()) {
			claims.addAll(removed);
			return -1;
		}
		return removed.size();
	}

	public boolean save() {
		return ClaimStorage.save(dataFile, claims);
	}
}
