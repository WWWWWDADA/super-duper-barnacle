package cn.simpleclaims.mixin;

import cn.simpleclaims.protection.ProtectionHandler;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Guard at the start of the server's block-use path. This runs even while the
 * player is sneaking, which is important because vanilla skips
 * BlockState.useItemOn in that case and would otherwise allow sneak-placing
 * blocks inside a claim.
 */
@Mixin(ServerPlayerGameMode.class)
public class ServerPlayerGameModeMixin {
	@Inject(method = "useItemOn", at = @At("HEAD"), cancellable = true)
	private void simpleclaims$guardUseItemOn(ServerPlayer player, Level level, ItemStack stack,
			InteractionHand hand, BlockHitResult hit, CallbackInfoReturnable<InteractionResult> callback) {
		InteractionResult result = ProtectionHandler.onUseItemOnIntercepted(player, level, stack, hand, hit);
		if (result != null) {
			callback.setReturnValue(result);
		}
	}
}
