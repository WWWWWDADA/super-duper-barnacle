package cn.simpleclaims.command;

import cn.simpleclaims.SimpleClaims;
import cn.simpleclaims.claim.Claim;
import cn.simpleclaims.claim.ClaimManager;
import cn.simpleclaims.claim.TrustedPlayer;
import cn.simpleclaims.config.ClaimConfig;
import cn.simpleclaims.protection.ProtectionHandler;
import cn.simpleclaims.ui.Messages;
import cn.simpleclaims.util.ClaimTool;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * The entire user interface is command based, so it works for vanilla clients
 * without installing anything on the client.
 */
public final class ClaimCommands {
	private static final long CONFIRM_TIMEOUT_MS = 30_000L;
	private static final Map<UUID, PendingDelete> PENDING_DELETES = new HashMap<>();

	private ClaimCommands() {
	}

	public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("claim")
				.executes(context -> overview(context.getSource()))
				.then(Commands.literal("help")
						.executes(context -> help(context.getSource())))
				.then(Commands.literal("tool")
						.executes(context -> tool(context.getSource())))
				.then(Commands.literal("create")
						.executes(context -> create(context.getSource())))
				.then(Commands.literal("info")
						.executes(context -> info(context.getSource())))
				.then(Commands.literal("list")
						.executes(context -> list(context.getSource())))
				.then(Commands.literal("trust")
						.then(Commands.argument("player", StringArgumentType.word())
								.suggests(ClaimCommands::suggestTrustCandidates)
								.executes(context -> trust(context.getSource(),
										StringArgumentType.getString(context, "player")))))
				.then(Commands.literal("untrust")
						.then(Commands.argument("player", StringArgumentType.word())
								.suggests(ClaimCommands::suggestTrusted)
								.executes(context -> untrust(context.getSource(),
										StringArgumentType.getString(context, "player")))))
				.then(Commands.literal("delete")
						.executes(context -> requestDelete(context.getSource()))
						.then(Commands.literal("confirm")
								.executes(context -> confirmDelete(context.getSource()))))
				.then(adminNode());

		dispatcher.register(root);
	}

	private static LiteralArgumentBuilder<CommandSourceStack> adminNode() {
		return Commands.literal("admin")
				.requires(source -> Commands.LEVEL_GAMEMASTERS.check(source.permissions()))
				.then(Commands.literal("list")
						.executes(context -> adminList(context.getSource(), null))
						.then(Commands.argument("player", StringArgumentType.word())
								.suggests(ClaimCommands::suggestOwners)
								.executes(context -> adminList(context.getSource(),
										StringArgumentType.getString(context, "player")))))
				.then(Commands.literal("info")
						.executes(context -> adminInfo(context.getSource())))
				.then(Commands.literal("unclaim")
						.executes(context -> adminUnclaim(context.getSource())))
				.then(Commands.literal("delete")
						.then(Commands.argument("player", StringArgumentType.word())
								.suggests(ClaimCommands::suggestOwners)
								.executes(context -> adminDelete(context.getSource(),
										StringArgumentType.getString(context, "player"), false))
								.then(Commands.literal("confirm")
										.executes(context -> adminDelete(context.getSource(),
												StringArgumentType.getString(context, "player"), true)))))
				.then(Commands.literal("reload")
						.executes(context -> adminReload(context.getSource())));
	}

	private static int overview(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim current = manager.findAt(player.level(), player.blockPosition());
		int owned = manager.countOf(player.getUUID());

		send(source, Messages.plain("===== 简易领地 =====", ChatFormatting.GOLD));
		if (current == null) {
			send(source, Messages.info("脚下：无主之地"));
		} else {
			send(source, Messages.info("脚下：" + displayOwner(player, current) + "的领地（"
					+ accessLabel(player, current) + "）"));
		}
		send(source, Messages.info("我的领地：" + owned + "/" + SimpleClaims.CONFIG.maxClaimsPerPlayer));

		MutableComponent buttons = Component.literal(" ")
				.append(Messages.button("[领取领地工具]", "/claim tool", ChatFormatting.GOLD))
				.append(Component.literal("  "))
				.append(Messages.button("[完整帮助]", "/claim help", ChatFormatting.AQUA));
		send(source, buttons);
		send(source, Messages.plain("快速开始：右键方块选角 1，左键方块选角 2，领地立即创建。", ChatFormatting.GRAY));
		return 1;
	}

	private static int help(CommandSourceStack source) {
		send(source, Messages.plain("===== 简易领地 · 帮助 =====", ChatFormatting.GOLD));
		send(source, Messages.plain("/claim tool", ChatFormatting.AQUA)
				.append(Component.literal("  领取圈地金铲").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("圈地步骤", ChatFormatting.AQUA)
				.append(Component.literal("  手持金铲右键方块选角 1，再左键点击对角方块，领地立即创建。").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("/claim", ChatFormatting.AQUA)
				.append(Component.literal("  查看脚下领地和快捷按钮").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("/claim info", ChatFormatting.AQUA)
				.append(Component.literal("  查看脚下领地详情").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("/claim list", ChatFormatting.AQUA)
				.append(Component.literal("  查看自己的全部领地").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("/claim trust <玩家>", ChatFormatting.AQUA)
				.append(Component.literal("  在脚下自己的领地里信任玩家").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("/claim untrust <玩家>", ChatFormatting.AQUA)
				.append(Component.literal("  取消信任").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("/claim delete", ChatFormatting.AQUA)
				.append(Component.literal("  删除脚下自己的领地（需再次确认）").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("规则", ChatFormatting.AQUA)
				.append(Component.literal("  领地保护整列高度；领主、被信任的玩家和管理员可以放置/破坏方块、打开容器。").withStyle(ChatFormatting.GRAY)));
		send(source, Messages.plain("管理员：/claim admin list | info | unclaim | delete | reload", ChatFormatting.DARK_GRAY));
		return 1;
	}

	private static int tool(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		if (player == null) {
			return 0;
		}
		ClaimTool.give(player);
		send(source, Messages.success("已领取领地工具。右键选角 1，左键选角 2 并创建领地。"));
		player.sendOverlayMessage(Messages.overlay("已领取领地工具", ChatFormatting.GOLD));
		return 1;
	}

	private static int create(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		if (player == null) {
			return 0;
		}
		if (SimpleClaims.CLAIMS == null) {
			source.sendFailure(Messages.error("领地系统尚未加载，请稍后再试。"));
			return 0;
		}
		return ProtectionHandler.createFromSelection(player) ? 1 : 0;
	}

	private static int info(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim claim = manager.findAt(player.level(), player.blockPosition());
		if (claim == null) {
			send(source, Messages.info("你脚下是无主之地。"));
			send(source, Messages.plain("圈地：/claim tool，然后右键选角 1，左键选角 2。", ChatFormatting.GRAY));
			return 0;
		}

		sendClaimInfo(source, player, claim, ProtectionHandler.isAdmin(player));
		return 1;
	}

	private static int list(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		List<Claim> claims = manager.claimsOf(player.getUUID());
		send(source, Messages.plain("===== 我的领地 (" + claims.size() + "/"
				+ SimpleClaims.CONFIG.maxClaimsPerPlayer + ") =====", ChatFormatting.GOLD));
		if (claims.isEmpty()) {
			send(source, Messages.info("你还没有领地。输入 /claim tool 开始圈地。"));
			return 0;
		}

		Claim current = manager.findAt(player.level(), player.blockPosition());
		int index = 1;
		for (Claim claim : claims) {
			MutableComponent line = Component.literal(index + ". ").withStyle(ChatFormatting.GRAY)
					.append(Component.literal(dimensionName(claim.dimension())).withStyle(ChatFormatting.AQUA))
					.append(Component.literal(" (" + claim.minX() + ", " + claim.minZ() + ") 到 ("
							+ claim.maxX() + ", " + claim.maxZ() + ") " + claim.widthX() + "×" + claim.widthZ())
							.withStyle(ChatFormatting.WHITE))
					.append(Component.literal("  信任 " + claim.trusted().size() + " 人").withStyle(ChatFormatting.GRAY));
			if (current != null && current.id().equals(claim.id())) {
				line.append(Component.literal("  [你在这里]").withStyle(ChatFormatting.GREEN));
			}
			send(source, line);
			index++;
		}
		return 1;
	}

	private static int trust(CommandSourceStack source, String name) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim claim = manager.findAt(player.level(), player.blockPosition());
		if (claim == null) {
			source.sendFailure(Messages.error("请先站在自己的领地里，再输入这个指令。"));
			return 0;
		}
		if (!claim.isOwner(player.getUUID())) {
			source.sendFailure(Messages.error("只有领主可以管理信任名单。"));
			return 0;
		}

		ServerPlayer target = findOnlinePlayer(source, name);
		if (target == null) {
			source.sendFailure(Messages.error("玩家 " + name + " 不在线。请让 TA 先上线。"));
			return 0;
		}
		if (target.getUUID().equals(player.getUUID())) {
			source.sendFailure(Messages.error("你是领主，不需要信任自己。"));
			return 0;
		}
		if (claim.isTrusted(target.getUUID())) {
			send(source, Messages.info(target.getPlainTextName() + " 已经在信任名单里了。"));
			return 0;
		}

		if (!manager.addTrusted(claim, target.getUUID(), target.getPlainTextName())) {
			source.sendFailure(Messages.error("保存失败，请稍后重试或联系管理员。"));
			return 0;
		}

		send(source, Messages.success("已信任 " + target.getPlainTextName() + "。TA 现在可以使用和打开这块领地里的方块与容器。"));
		target.sendSystemMessage(Messages.info(player.getPlainTextName() + " 信任了你，你可以进入 TA 的领地并使用容器。"));
		return 1;
	}

	private static int untrust(CommandSourceStack source, String name) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim claim = manager.findAt(player.level(), player.blockPosition());
		if (claim == null) {
			source.sendFailure(Messages.error("请先站在自己的领地里，再输入这个指令。"));
			return 0;
		}
		if (!claim.isOwner(player.getUUID())) {
			source.sendFailure(Messages.error("只有领主可以管理信任名单。"));
			return 0;
		}

		ServerPlayer online = findOnlinePlayer(source, name);
		TrustedPlayer target = online == null ? null : claim.findTrusted(online.getUUID()).orElse(null);
		if (target == null) {
			target = claim.findTrustedByName(name).orElse(null);
		}
		if (target == null) {
			source.sendFailure(Messages.error("信任名单里没有 " + name + "。"));
			return 0;
		}

		if (!manager.removeTrusted(claim, target.id())) {
			source.sendFailure(Messages.error("保存失败，请稍后重试或联系管理员。"));
			return 0;
		}

		send(source, Messages.success("已取消信任 " + target.name() + "。"));
		if (online != null) {
			online.sendSystemMessage(Messages.warning(player.getPlainTextName() + " 取消了对你的领地信任。"));
		}
		return 1;
	}

	private static int requestDelete(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim claim = manager.findAt(player.level(), player.blockPosition());
		if (claim == null) {
			source.sendFailure(Messages.error("你脚下没有领地。"));
			return 0;
		}
		if (!claim.isOwner(player.getUUID())) {
			source.sendFailure(Messages.error("只有领主可以删除这块领地。管理员可使用 /claim admin unclaim。"));
			return 0;
		}

		PENDING_DELETES.put(player.getUUID(), new PendingDelete(claim.id(),
				System.currentTimeMillis() + CONFIRM_TIMEOUT_MS));
		source.sendSuccess(() -> Messages.warning("确定删除脚下的领地吗？范围 " + claim.widthX() + "×"
				+ claim.widthZ() + "，此操作不可撤销。"), false);
		MutableComponent confirm = Component.literal(" ")
				.append(Messages.button("[确认删除]", "/claim delete confirm", ChatFormatting.RED));
		send(source, confirm);
		send(source, Messages.plain("也可以输入 /claim delete confirm。30 秒内有效。", ChatFormatting.GRAY));
		return 1;
	}

	private static int confirmDelete(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		PendingDelete pending = PENDING_DELETES.get(player.getUUID());
		if (pending == null || pending.expiresAt() < System.currentTimeMillis()) {
			PENDING_DELETES.remove(player.getUUID());
			source.sendFailure(Messages.error("没有待确认的删除操作，或确认已过期。"));
			return 0;
		}

		Optional<Claim> claimOptional = manager.findById(pending.claimId());
		if (claimOptional.isEmpty()) {
			PENDING_DELETES.remove(player.getUUID());
			source.sendFailure(Messages.error("这块领地已经不存在了。"));
			return 0;
		}

		Claim claim = claimOptional.get();
		if (!claim.isOwner(player.getUUID())) {
			PENDING_DELETES.remove(player.getUUID());
			source.sendFailure(Messages.error("只有领主可以删除这块领地。"));
			return 0;
		}

		if (!manager.delete(claim)) {
			source.sendFailure(Messages.error("删除失败，保存时出错。请稍后重试或联系管理员。"));
			return 0;
		}

		PENDING_DELETES.remove(player.getUUID());
		ProtectionHandler.clearSelection(player.getUUID());
		send(source, Messages.success("领地已删除。"));
		player.sendOverlayMessage(Messages.overlay("领地已删除", ChatFormatting.YELLOW));
		SimpleClaims.LOGGER.info("{} deleted claim {} ({})", player.getPlainTextName(), claim.id(), claim.ownerName());
		return 1;
	}

	private static int adminList(CommandSourceStack source, String filter) {
		ClaimManager manager = requireManager(source);
		if (manager == null) {
			return 0;
		}

		List<Claim> claims;
		String header;
		if (filter == null) {
			claims = new ArrayList<>(manager.allClaims());
			header = "===== 全部领地 (" + claims.size() + ") =====";
		} else {
			ServerPlayer online = findOnlinePlayer(source, filter);
			if (online != null) {
				claims = manager.claimsOf(online.getUUID());
				header = "===== " + online.getPlainTextName() + " 的领地 (" + claims.size() + ") =====";
			} else {
				claims = manager.claimsByName(filter);
				header = "===== " + filter + " 的领地 (" + claims.size() + ") =====";
			}
		}

		send(source, Messages.plain(header, ChatFormatting.GOLD));
		if (claims.isEmpty()) {
			send(source, Messages.info("没有找到领地。"));
			return 0;
		}

		claims.sort(Comparator.comparing(Claim::ownerName, String.CASE_INSENSITIVE_ORDER)
				.thenComparingLong(Claim::createdAt));
		int shown = 0;
		for (Claim claim : claims) {
			if (shown >= 50) {
				send(source, Messages.warning("只显示前 50 块领地。"));
				break;
			}
			send(source, Messages.plain(claim.ownerName() + "  " + dimensionName(claim.dimension())
					+ " (" + claim.minX() + ", " + claim.minZ() + ") 到 (" + claim.maxX() + ", " + claim.maxZ()
					+ ")  " + claim.widthX() + "×" + claim.widthZ() + "  信任 " + claim.trusted().size() + " 人",
					ChatFormatting.GRAY));
			shown++;
		}
		return 1;
	}

	private static int adminInfo(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim claim = manager.findAt(player.level(), player.blockPosition());
		if (claim == null) {
			source.sendFailure(Messages.error("你脚下没有领地。"));
			return 0;
		}
		sendClaimInfo(source, player, claim, true);
		return 1;
	}

	private static int adminUnclaim(CommandSourceStack source) {
		ServerPlayer player = requirePlayer(source);
		ClaimManager manager = requireManager(source);
		if (player == null || manager == null) {
			return 0;
		}

		Claim claim = manager.findAt(player.level(), player.blockPosition());
		if (claim == null) {
			source.sendFailure(Messages.error("你脚下没有领地。"));
			return 0;
		}
		if (!manager.delete(claim)) {
			source.sendFailure(Messages.error("删除失败，保存时出错。"));
			return 0;
		}
		send(source, Messages.success("已删除 " + claim.ownerName() + " 的领地（"
				+ dimensionName(claim.dimension()) + " " + claim.minX() + "," + claim.minZ() + "）。"));
		SimpleClaims.LOGGER.info("{} deleted claim {} of {} via admin command",
				source.getTextName(), claim.id(), claim.ownerName());
		return 1;
	}

	private static int adminDelete(CommandSourceStack source, String name, boolean confirm) {
		ClaimManager manager = requireManager(source);
		if (manager == null) {
			return 0;
		}

		ServerPlayer online = findOnlinePlayer(source, name);
		List<Claim> claims = online != null ? manager.claimsOf(online.getUUID()) : manager.claimsByName(name);
		if (claims.isEmpty()) {
			source.sendFailure(Messages.error("没有找到 " + name + " 的领地。"));
			return 0;
		}

		if (!confirm) {
			source.sendSuccess(() -> Messages.warning("将删除 " + name + " 的 " + claims.size()
					+ " 块领地。确认请输入 /claim admin delete " + name + " confirm"), false);
			return 1;
		}

		int deleted = manager.deleteAll(claims);
		if (deleted < 0) {
			source.sendFailure(Messages.error("删除失败，保存时出错。"));
			return 0;
		}
		send(source, Messages.success("已删除 " + name + " 的 " + deleted + " 块领地。"));
		SimpleClaims.LOGGER.info("{} deleted {} claim(s) of {} via admin command",
				source.getTextName(), deleted, name);
		return 1;
	}

	private static int adminReload(CommandSourceStack source) {
		SimpleClaims.reloadConfig();
		ClaimConfig config = SimpleClaims.CONFIG;
		send(source, Messages.success("配置已重新加载：领地数量上限 " + config.maxClaimsPerPlayer
				+ "，单边 " + config.minClaimWidth + "-" + config.maxClaimWidth + " 格。"));
		return 1;
	}

	private static void sendClaimInfo(CommandSourceStack source, ServerPlayer viewer, Claim claim, boolean admin) {
		send(source, Messages.plain("--- 领地信息 ---", ChatFormatting.GOLD));
		send(source, Messages.info("领主：" + displayOwner(viewer, claim)));
		send(source, Messages.info("世界：" + dimensionName(claim.dimension())));
		send(source, Messages.info("范围：(" + claim.minX() + ", " + claim.minZ() + ") 到 ("
				+ claim.maxX() + ", " + claim.maxZ() + ")"));
		send(source, Messages.info("大小：" + claim.widthX() + "×" + claim.widthZ()
				+ "（保护整列高度）"));
		send(source, Messages.info("信任：" + formatTrusted(claim)));
		send(source, Messages.info("你的权限：" + accessLabel(viewer, claim)));

		if (admin) {
			send(source, Messages.plain("领地 ID：" + claim.id(), ChatFormatting.DARK_GRAY));
			send(source, Messages.plain("领主 UUID：" + claim.ownerId(), ChatFormatting.DARK_GRAY));
		}
	}

	private static String formatTrusted(Claim claim) {
		if (claim.trusted().isEmpty()) {
			return "无";
		}
		List<String> names = claim.trusted().stream().map(TrustedPlayer::name).limit(8).collect(Collectors.toList());
		String result = String.join("、", names);
		if (claim.trusted().size() > names.size()) {
			result += " 等 " + claim.trusted().size() + " 人";
		}
		return result;
	}

	private static String accessLabel(ServerPlayer player, Claim claim) {
		if (ProtectionHandler.isAdmin(player)) {
			return "管理员（全部权限）";
		}
		if (claim.isOwner(player.getUUID())) {
			return "领主";
		}
		if (claim.isTrusted(player.getUUID())) {
			return "已信任";
		}
		return "无权限";
	}

	private static String displayOwner(ServerPlayer viewer, Claim claim) {
		ServerPlayer online = viewer.level().getServer().getPlayerList().getPlayer(claim.ownerId());
		return online != null ? online.getPlainTextName() : claim.ownerName();
	}

	public static String dimensionName(String dimension) {
		return switch (dimension) {
			case "minecraft:overworld" -> "主世界";
			case "minecraft:the_nether" -> "下界";
			case "minecraft:the_end" -> "末地";
			default -> dimension.startsWith("minecraft:")
					? dimension.substring("minecraft:".length())
					: dimension;
		};
	}

	private static ServerPlayer requirePlayer(CommandSourceStack source) {
		ServerPlayer player = source.getPlayer();
		if (player == null) {
			source.sendFailure(Messages.error("这个指令只能由玩家执行。"));
		}
		return player;
	}

	private static ClaimManager requireManager(CommandSourceStack source) {
		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager == null) {
			source.sendFailure(Messages.error("领地系统尚未加载，请稍后再试。"));
		}
		return manager;
	}

	private static ServerPlayer findOnlinePlayer(CommandSourceStack source, String name) {
		ServerPlayer player = source.getServer().getPlayerList().getPlayer(name);
		if (player != null) {
			return player;
		}
		for (ServerPlayer candidate : source.getServer().getPlayerList().getPlayers()) {
			if (candidate.getPlainTextName().equalsIgnoreCase(name)) {
				return candidate;
			}
		}
		return null;
	}

	private static void send(CommandSourceStack source, Component component) {
		source.sendSuccess(() -> component, false);
	}

	private static CompletableFuture<Suggestions> suggestTrustCandidates(CommandContext<CommandSourceStack> context,
			SuggestionsBuilder builder) {
		ServerPlayer self = context.getSource().getPlayer();
		ClaimManager manager = SimpleClaims.CLAIMS;
		Claim claim = self != null && manager != null
				? manager.findAt(self.level(), self.blockPosition())
				: null;
		if (claim != null && self != null && !claim.isOwner(self.getUUID())) {
			return builder.buildFuture();
		}
		String remaining = builder.getRemaining().toLowerCase(Locale.ROOT);
		for (String name : context.getSource().getOnlinePlayerNames()) {
			if (self != null && name.equalsIgnoreCase(self.getPlainTextName())) {
				continue;
			}
			if (name.toLowerCase(Locale.ROOT).startsWith(remaining)) {
				builder.suggest(name);
			}
		}
		return builder.buildFuture();
	}

	private static CompletableFuture<Suggestions> suggestTrusted(CommandContext<CommandSourceStack> context,
			SuggestionsBuilder builder) {
		ServerPlayer self = context.getSource().getPlayer();
		ClaimManager manager = SimpleClaims.CLAIMS;
		if (self == null || manager == null) {
			return builder.buildFuture();
		}
		Claim claim = manager.findAt(self.level(), self.blockPosition());
		if (claim == null || !claim.isOwner(self.getUUID())) {
			return builder.buildFuture();
		}
		String remaining = builder.getRemaining().toLowerCase(Locale.ROOT);
		for (TrustedPlayer trusted : claim.trusted()) {
			if (trusted.name().toLowerCase(Locale.ROOT).startsWith(remaining)) {
				builder.suggest(trusted.name());
			}
		}
		return builder.buildFuture();
	}

	private static CompletableFuture<Suggestions> suggestOwners(CommandContext<CommandSourceStack> context,
			SuggestionsBuilder builder) {
		String remaining = builder.getRemaining().toLowerCase(Locale.ROOT);
		Set<String> names = new HashSet<>(context.getSource().getOnlinePlayerNames());
		ClaimManager manager = SimpleClaims.CLAIMS;
		if (manager != null) {
			for (Claim claim : manager.allClaims()) {
				names.add(claim.ownerName());
			}
		}
		for (String name : names) {
			if (name.toLowerCase(Locale.ROOT).startsWith(remaining)) {
				builder.suggest(name);
			}
		}
		return builder.buildFuture();
	}

	public static void cleanup(Set<UUID> online) {
		long now = System.currentTimeMillis();
		PENDING_DELETES.entrySet().removeIf(entry -> !online.contains(entry.getKey())
				|| entry.getValue().expiresAt() < now);
	}

	private record PendingDelete(UUID claimId, long expiresAt) {
	}
}
