package cn.simpleclaims.ui;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Small helpers for consistently formatted, server-side chat messages.
 */
public final class Messages {
	public static final String PREFIX_TEXT = "[简易领地] ";

	private Messages() {
	}

	public static MutableComponent prefix() {
		return Component.literal(PREFIX_TEXT).withStyle(ChatFormatting.DARK_AQUA);
	}

	public static MutableComponent info(String text) {
		return prefix().append(Component.literal(text).withStyle(ChatFormatting.WHITE));
	}

	public static MutableComponent success(String text) {
		return prefix().append(Component.literal(text).withStyle(ChatFormatting.GREEN));
	}

	public static MutableComponent error(String text) {
		return prefix().append(Component.literal(text).withStyle(ChatFormatting.RED));
	}

	public static MutableComponent warning(String text) {
		return prefix().append(Component.literal(text).withStyle(ChatFormatting.YELLOW));
	}

	public static Component overlay(String text, ChatFormatting color) {
		return Component.literal(text).withStyle(color);
	}

	public static MutableComponent button(String label, String command, ChatFormatting color) {
		return Component.literal(label).withStyle(style -> style
				.withColor(color)
				.withClickEvent(new ClickEvent.RunCommand(command)));
	}

	public static MutableComponent plain(String text, ChatFormatting color) {
		return Component.literal(text).withStyle(color);
	}

}
